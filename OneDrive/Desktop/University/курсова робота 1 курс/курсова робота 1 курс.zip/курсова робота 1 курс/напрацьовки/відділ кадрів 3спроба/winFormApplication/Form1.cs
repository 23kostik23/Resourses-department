using System.Diagnostics;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using System.Xml.Linq;
using ����_�����_3������;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private TextBox inputTextBox;
        private ResoursesDepartament database = new ResoursesDepartament();
        private TextBox textBox;
        public Form1()
        {
            InitializeComponent();
            this.Size = new Size(840, 650);
            InitializeInput();
            InitializeTextBox();
        }

        private void InitializeTextBox()
        {
            textBox = new TextBox();
            textBox.Multiline = true;
            textBox.ReadOnly = true;
            textBox.ScrollBars = ScrollBars.Vertical;
            textBox.Size = new Size(600, 300);
            int TextBoxWidth = (this.ClientSize.Width - 600) / 2;
            textBox.Location = new Point(TextBoxWidth, 100);
            Controls.Add(textBox);
        }

        private void InitializeInput()
        {
            TextBox inputTextBoxLabel = new TextBox();
            inputTextBoxLabel.ReadOnly = true;
            inputTextBoxLabel.TextAlign = HorizontalAlignment.Center;
            inputTextBoxLabel.Text = "Type commands: Print, Load, Hire, Fire, Help, Save, Stop";
            inputTextBoxLabel.Size = new System.Drawing.Size(400, 30);
            inputTextBoxLabel.Location = new Point(200, 0);
            Controls.Add(inputTextBoxLabel);

            inputTextBox = new TextBox();
            inputTextBox.Multiline = true;
            inputTextBox.ScrollBars = ScrollBars.Vertical;
            inputTextBox.Size = new System.Drawing.Size(200, 50);
            inputTextBox.Location = new System.Drawing.Point(300, 30);
            inputTextBox.KeyDown += InputTextBox_KeyDown;
            inputTextBox.TabIndex = 0;
            Controls.Add(inputTextBox);
        }

        private Worker CreateWorker(TextBox NameInput, TextBox AgeInput, ComboBox SexInput, TextBox SalaryInput, ComboBox EducationInput, TextBox PositionInput, TextBox DivisionInput)
        {
            string name = NameInput.Text;
            if(name.Length == 0)
            {
                name = "Name Surname";
            }
            int age;
            bool isAgeValid = int.TryParse(AgeInput.Text, out age);
            if(age < 18)
            {
                age = 18;
            }
            else if(age > 150)
            {
                age = 149;
            }
            string sex = SexInput.SelectedItem.ToString();
            int salary;
            bool isSalaryValid = int.TryParse(SalaryInput.Text, out salary);
            if(salary <= 0)
            {
                salary = 600;
            }
            string education = EducationInput.Text;
            string position = PositionInput.Text;
            string division = DivisionInput.Text;
            while (string.IsNullOrWhiteSpace(name) || !isAgeValid || string.IsNullOrWhiteSpace(sex) ||
            !isSalaryValid || string.IsNullOrWhiteSpace(education) || string.IsNullOrWhiteSpace(position) ||
            string.IsNullOrWhiteSpace(division))
            {
                MessageBox.Show("Fields filled with invalid data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                break;
            }

            if (name.Split(' ').Count() == 2)
            {
                string[] newName = name.Split(' ');
                newName[0] = char.ToUpper(newName[0][0]) + newName[0].Substring(1);
                newName[1] = char.ToUpper(newName[1][0]) + newName[1].Substring(1);
                name = string.Join(" ", newName);
            }
            else if (name.Split(' ').Count() > 2)
            {
                name = char.ToUpper(name[0]) + name.Substring(1);
                string[] newName = name.Split(' ');
                name = newName[0] + " Surname";
            }
            education = char.ToUpper(education[0]) + education.Substring(1);
            if(position.Length == 0)
            {
                position = "Office";
            }
            position = char.ToUpper(position[0]) + position.Substring(1);
            if(division.Length == 0)
            {
                division = "Div1";
            }
            division = char.ToUpper(division[0]) + division.Substring(1);
            Worker newWorker = new Worker(name, age, sex, salary, education, position, division);
            return newWorker;
        }

        private void InitializeWorkerParametersInput(string command)
        {
            TextBox NameLabel = new TextBox();
            NameLabel.ReadOnly = true;
            NameLabel.TextAlign = HorizontalAlignment.Center;
            NameLabel.Text = "Name(string)";
            NameLabel.Location = new Point(20, 430);
            Controls.Add(NameLabel);
            TextBox NameInput = new TextBox();
            NameInput.Multiline = true;
            NameInput.Size = new Size(NameLabel.Width, 50);
            NameInput.Location = new Point(20, 455);
            NameInput.TabIndex = 1;
            Controls.Add(NameInput);

            TextBox AgeLabel = new TextBox();
            AgeLabel.ReadOnly = true;
            AgeLabel.TextAlign = HorizontalAlignment.Center;
            AgeLabel.Text = "Age(int)";
            AgeLabel.Location = new Point(20 + NameLabel.Width, 430);
            Controls.Add(AgeLabel);
            TextBox AgeInput = new TextBox();
            AgeInput.Multiline = true;
            AgeInput.Size = new Size(NameLabel.Width, 50);
            AgeInput.Location = new Point(20 + NameLabel.Width, 455);
            AgeInput.TabIndex = 2;
            Controls.Add(AgeInput);

            TextBox SexLabel = new TextBox();
            SexLabel.ReadOnly = true;
            SexLabel.TextAlign = HorizontalAlignment.Center;
            SexLabel.Text = "Sex";
            SexLabel.Location = new Point(120 + AgeLabel.Width, 430);
            SexLabel.Size = new Size(120, NameLabel.Height);
            Controls.Add(SexLabel);
            ComboBox SexInput = new ComboBox();
            SexInput.Location = new Point(120 + AgeLabel.Width, 455);
            SexInput.Items.AddRange(new string[] { "Male", "Female" });
            SexInput.DropDownStyle = ComboBoxStyle.DropDownList;
            SexInput.SelectedIndex = 0;
            SexInput.TabIndex = 3;
            Controls.Add(SexInput);

            TextBox SalaryLabel = new TextBox();
            SalaryLabel.ReadOnly = true;
            SalaryLabel.TextAlign = HorizontalAlignment.Center;
            SalaryLabel.Text = "Salary(int)";
            SalaryLabel.Location = new Point(220 + SexLabel.Width, 430);
            Controls.Add(SalaryLabel);
            TextBox SalaryInput = new TextBox();
            SalaryInput.Multiline = true;
            SalaryInput.Size = new Size(NameLabel.Width, 50);
            SalaryInput.Location = new Point(220 + SexLabel.Width, 450);
            SalaryInput.TabIndex = 4;
            Controls.Add(SalaryInput);

            TextBox EducationLabel = new TextBox();
            EducationLabel.ReadOnly = true;
            EducationLabel.TextAlign = HorizontalAlignment.Center;
            EducationLabel.Text = "Education(string)";
            EducationLabel.Size = new Size(120, NameLabel.Height);
            EducationLabel.Location = new Point(320 + SexLabel.Width, 430);
            Controls.Add(EducationLabel);
            ComboBox EducationInput = new ComboBox();
            EducationInput.Location = new Point(340 + AgeLabel.Width, 455);
            EducationInput.Items.AddRange(new string[] { "BA", "MA", "PhD" });
            EducationInput.DropDownStyle = ComboBoxStyle.DropDownList;
            EducationInput.SelectedIndex = 0;
            EducationInput.TabIndex = 5;
            Controls.Add(EducationInput);

            TextBox PositionLabel = new TextBox();
            PositionLabel.ReadOnly = true;
            PositionLabel.TextAlign = HorizontalAlignment.Center;
            PositionLabel.Text = "Position(string)";
            PositionLabel.Size = new Size(120, NameLabel.Height);
            PositionLabel.Location = new Point(440 + SexLabel.Width, 430);
            Controls.Add(PositionLabel);
            TextBox PositionInput = new TextBox();
            PositionInput.Multiline = true;
            PositionInput.Size = new Size(NameLabel.Width + 20, 50);
            PositionInput.Location = new Point(440 + SexLabel.Width, 450);
            PositionInput.TabIndex = 6;
            Controls.Add(PositionInput);

            TextBox DivisionLabel = new TextBox();
            DivisionLabel.ReadOnly = true;
            DivisionLabel.TextAlign = HorizontalAlignment.Center;
            DivisionLabel.Text = "Division(string)";
            DivisionLabel.Size = new Size(140, NameLabel.Height);
            DivisionLabel.Location = new Point(540 + SexLabel.Width, 430);
            Controls.Add(DivisionLabel);
            TextBox DivisionInput = new TextBox();
            DivisionInput.Multiline = true;
            DivisionInput.Size = new Size(NameLabel.Width + 20, 50);
            DivisionInput.Location = new Point(560 + SexLabel.Width, 450);
            DivisionInput.TabIndex = 7;
            Controls.Add(DivisionInput);

            Button Create = new Button();
            Create.Text = "Create";
            Create.Size = new Size(100, 50);
            Create.Location = new Point((Width / 2) - 50, 530);
            Create.TabIndex = 8;
            Controls.Add(Create);
            Create.Click += (sender, e) =>
            {
                if (command == "Hire")
                {
                    Worker tempWorker = new Worker();
                    tempWorker = CreateWorker(NameInput, AgeInput, SexInput, SalaryInput, EducationInput, PositionInput, DivisionInput);
                    database.AddWorkerForForms(tempWorker);
                    database.CreateHireOrderTxtForForms(tempWorker);
                    database.SaveResoursesDepartament();
                    textBox.Text = "Worker was succesfully hired";
                }
                else if (command == "Fire")
                {
                    Worker tempWorker = new Worker();
                    tempWorker = CreateWorker(NameInput, AgeInput, SexInput, SalaryInput, EducationInput, PositionInput, DivisionInput);
                    database.CreateFireOrderTxtForForms(tempWorker);
                    database.RemoveWorkerForForms(tempWorker);
                    database.SaveResoursesDepartament();
                    textBox.Text = "Worker was succesfully fired";
                }
                else MessageBox.Show("�� ������� � ����� InitializeWorkerParametersInput() ������������ ��������", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                NameLabel.Visible = false;
                NameInput.Visible = false;
                AgeLabel.Visible = false;
                AgeInput.Visible = false;
                SexLabel.Visible = false;
                SexInput.Visible = false;
                SalaryLabel.Visible = false;
                SalaryInput.Visible = false;
                EducationLabel.Visible = false;
                EducationInput.Visible = false;
                PositionLabel.Visible = false;
                PositionInput.Visible = false;
                DivisionLabel.Visible = false;
                DivisionInput.Visible = false;
                Create.Visible = false;
            };
        }

        private string command = "";
        private void InputTextBox_KeyDown(object sender, KeyEventArgs key)
        {
            if (key.KeyCode == Keys.Enter)
            {
                command = inputTextBox.Text;
                if (command.Length == 0 || string.IsNullOrWhiteSpace(command))
                {
                    inputTextBox.Clear();
                    command = "NOTHING";
                }
                else
                {
                    command = command.Trim();
                    command = char.ToUpper(command[0]) + command.Substring(1);
                }
                if (command == "Load")
                {
                    inputTextBox.Clear();
                    database.LoadResoursedDepartamment();
                    textBox.Text = "Data has succesfully been loaded";
                }
                else if (command == "Print")
                {
                    textBox.Text = database.ToString();
                    inputTextBox.Clear();
                }
                else if (command == "Hire")
                {
                    inputTextBox.Clear();
                    InitializeWorkerParametersInput("Hire");
                }
                else if (command == "Fire")
                {
                    inputTextBox.Clear();
                    if (database.CountWorkersForForms() >= 1)
                    {
                        InitializeWorkerParametersInput("Fire");
                    }
                    else
                    {
                        MessageBox.Show("� ������� ���� ��������", "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    };
                }
                else if (command == "Stop" || command == "Close")
                {
                    inputTextBox.Clear();
                    Close();
                }
                else if (command == "Save")
                {
                    inputTextBox.Clear();
                    database.SaveResoursesDepartament();
                    textBox.Text = "Data has succesfully been saved";
                }
                else if (command == "Help")
                {
                    inputTextBox.Clear();
                    textBox.Text = ($"Hire - adds worker to a company(database) and creates an .txt HireOrder\r\n" +
                                    $"Fire - deletes worker from a company(database) and creates an .txt FireOrder\r\n" +
                                    $"Print - prints all of your resourses departament(database)\r\n" +
                                    $"Stop - turns off the program\r\n" +
                                    $"Save - saves all of your resourses departament changes to an existing Database.txt file\r\n" +
                                    $"Load - loads all workers to your resourses departament from an existing Database.txt file\r\n" +
                                    $"Search - searches for workers by a certain parameter (only 1 parameter)\r\n" +
                                    $"Clear - to clear the console");
                }
                else
                {
                    inputTextBox.Clear();
                    textBox.Text = $"This command: '{command}' not found";
                }
                command = "";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}
