﻿using System.Globalization;
using System;
using System.IO;

namespace відділ_кадрів_3спроба
{
    public class Worker
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Sex { get; set; }
        public int Salary { get; set; }
        public string Eduction { get; set; }
        public string Position { get; set; }
        public string Division { get; set; } //Підрозділ
        public DateTime DateOfEntry { get; set; } = DateTime.Now; //Дата надходження
        public DateTime DateOfLastAppointment { get; set; }//Дата останнього призначення
        public Worker(string Name, int Age, string Sex, int Salary, string Education, string Position, string Division)
        {
            this.Name = Name;
            this.Age = Age;
            this.Sex = Sex;
            this.Salary = Salary;
            this.Eduction = Education;
            this.Position = Position;
            this.Division = Division;
            this.DateOfEntry = DateTime.Now;
            this.DateOfLastAppointment = DateTime.Now;
        }
        public Worker()
        {

        }
        public Worker(string Name, int Age, string Sex, int Salary, string Education, string Position, string Division, DateTime DateOfEntry, DateTime DateOfLastAppointment)
        {
            this.Name = Name;
            this.Age = Age;
            this.Sex = Sex;
            this.Salary = Salary;
            this.Eduction = Education;
            this.Position = Position;
            this.Division = Division;
            this.DateOfEntry = DateOfEntry;
            this.DateOfLastAppointment = DateOfLastAppointment;
        }
        public override string ToString()
        {
            return $"Name:{Name}, Age:{Age}, Sex:{Sex}, Salary:{Salary}, Education:{Eduction}, Position:{Position}, Division:{Division}, DateOfEntry:{DateOfEntry}, DateOfLastAppointment:{DateOfLastAppointment}";
        }

    }

    public class ResoursesDepartament
    {
        List<Worker> Workers = new List<Worker>();
        public int CountWorkersForForms()
        {
            return Workers.Count;
        }
        public void AddWorkerForForms(Worker worker)
        {
            Workers.Add(worker);
        }
        private void AddWorker(Worker worker)
        {
            Workers.Add(worker);
        }

        public void CreateHireOrderTxtForForms(Worker worker)
        {
            string fileName = $"HireOrder_{DateTime.Now:yyyyMMddHHmmss},_{worker.Name}.txt";
            string folderPath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів 3спроба\Orders";
            string filePath = Path.Combine(folderPath, fileName);
            File.WriteAllText(filePath, $"Наказ про прийняття на роботу.\n" +
                $"{worker.Name} було призначено на пост {worker.Position} у віці {worker.Age}.\n" +
                $"Отримуватиме фіксовану заробітню плату у розмірі: {worker.Salary}.\n" +
                $"Має {worker.Eduction} освіту.\n" +
                $"Стать співробітника: {worker.Sex}.\n" +
                $"Підрозділ у якому працюватиме: {worker.Division}.\n" +
                $"Дата надходження у фірму: {worker.DateOfEntry}.\n" +
                $"Дата останнього призначення на посаду: {worker.DateOfLastAppointment}.\n");
        }
        private void CreateHireOrderTxt(Worker worker)
        {
            string fileName = $"HireOrder_{DateTime.Now:yyyyMMddHHmmss},_{worker.Name}.txt";
            string folderPath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів 3спроба\Orders";
            string filePath = Path.Combine(folderPath, fileName);
            File.WriteAllText(filePath, $"Наказ про прийняття на роботу.\n" +
                $"{worker.Name} було призначено на пост {worker.Position} у віці {worker.Age}.\n" +
                $"Отримуватиме фіксовану заробітню плату у розмірі: {worker.Salary}.\n" +
                $"Має {worker.Eduction} освіту.\n" +
                $"Стать співробітника: {worker.Sex}.\n" +
                $"Підрозділ у якому працюватиме: {worker.Division}.\n" +
                $"Дата надходження у фірму: {worker.DateOfEntry}.\n" +
                $"Дата останнього призначення на посаду: {worker.DateOfLastAppointment}.\n");
        }

        public void CreateHireOrder()
        {
            Console.WriteLine("Hire order: ");
            Worker OrderWorker = GetWorkerParamsNoDateTime();
            AddWorker(OrderWorker);
            CreateHireOrderTxt(OrderWorker);
            this.SaveResoursesDepartament();
        }

        public void RemoveWorkerForForms(Worker worker)
        {
            for (int i = Workers.Count - 1; i >= 0; i--)
            {
                if (AreWorkersEqualForForms(worker, Workers[i]))
                {
                    Workers.RemoveAt(i);
                    break;
                }
            }
        }
        private void RemoveWorker(Worker worker)
        {
            for (int i = Workers.Count - 1; i >= 0; i--)
            {
                if (AreWorkersEqual(worker, Workers[i]))
                {
                    Workers.RemoveAt(i);
                }
            }
        }

        private void CreateFireOrderTxt(Worker worker)
        {
            string fileName = $"FireOrder_{DateTime.Now:yyyyMMddHHmmss},_{worker.Name}.txt";
            string folderPath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів 3спроба\Orders";
            string filePath = Path.Combine(folderPath, fileName);
            File.WriteAllText(filePath, $"Наказ про звільнення з роботи.\n" +
                $"{worker.Name} було звільнено з посту {worker.Position} у віці {worker.Age}.\n" +
                $"Отримував фіксовану заробітню плату у розмірі: {worker.Salary}.\n" +
                $"Має {worker.Eduction} освіту.\n" +
                $"Стать співробітника: {worker.Sex}.\n" +
                $"Підрозділ у якому працював: {worker.Division}.\n" +
                $"Дата надходження у фірму: {worker.DateOfEntry}.\n" +
                $"Дата останнього призначення на посаду: {worker.DateOfLastAppointment}.\n");
        }
        public void CreateFireOrderTxtForForms(Worker worker)
        {
            string fileName = $"FireOrder_{DateTime.Now:yyyyMMddHHmmss},_{worker.Name}.txt";
            string folderPath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів 3спроба\Orders";
            string filePath = Path.Combine(folderPath, fileName);
            File.WriteAllText(filePath, $"Наказ про звільнення з роботи.\n" +
                $"{worker.Name} було звільнено з посту {worker.Position} у віці {worker.Age}.\n" +
                $"Отримував фіксовану заробітню плату у розмірі: {worker.Salary}.\n" +
                $"Має {worker.Eduction} освіту.\n" +
                $"Стать співробітника: {worker.Sex}.\n" +
                $"Підрозділ у якому працював: {worker.Division}.\n" +
                $"Дата надходження у фірму: {worker.DateOfEntry}.\n" +
                $"Дата останнього призначення на посаду: {worker.DateOfLastAppointment}.\n");
        }

        private bool AreWorkersEqual(Worker a, Worker b)
        {
            if (a.Name != b.Name)
            {
                return false;
            }
            if (a.Age != b.Age)
            {
                return false;
            }
            if (a.Sex != b.Sex)
            {
                return false;
            }
            if (a.Salary != b.Salary)
            {
                return false;
            }
            if (a.Eduction != b.Eduction)
            {
                return false;
            }
            if (a.Position != b.Position)
            {
                return false;
            }
            if (a.Division != b.Division)
            {
                return false;
            }
            if (a.DateOfEntry.ToString("dd.MM.yyyy hh:mm:ss") != b.DateOfEntry.ToString("dd.MM.yyyy hh:mm:ss"))
            {
                return false;
            }
            if (a.DateOfLastAppointment.ToString("dd.MM.yyyy hh:mm:ss") != b.DateOfLastAppointment.ToString("dd.MM.yyyy hh:mm:ss"))
            {
                return false;
            }
            return true;
        }
        public bool AreWorkersEqualForForms(Worker a, Worker b)
        {
            if (a.Name != b.Name)
            {
                return false;
            }
            if (a.Age != b.Age)
            {
                return false;
            }
            if (a.Sex != b.Sex)
            {
                return false;
            }
            if (a.Salary != b.Salary)
            {
                return false;
            }
            if (a.Eduction != b.Eduction)
            {
                return false;
            }
            if (a.Position != b.Position)
            {
                return false;
            }
            if (a.Division != b.Division)
            {
                return false;
            }
            return true;
        }


        public void CreateFireOrder()
        {
            if (Workers.Count == 0)
            {
                Console.WriteLine($"\nResourses dapartment(database) is already empty\n");
                return;
            }
            Console.WriteLine("Fire order: ");
            Worker OrderWorker = GetWorkerParamsNoDateTime();
            OrderWorker = ChangeWorkerDateTime(OrderWorker);
            if (OrderWorker != null)
            {
                for (int i = 0; i < Workers.Count; i++)
                {
                    if (AreWorkersEqual(Workers[i], OrderWorker) == true)
                    {
                        CreateFireOrderTxt(Workers[i]);
                        RemoveWorker(Workers[i]);
                        break;
                    }
                    else Console.WriteLine(Workers[i].ToString() + "\t!=\t" + OrderWorker.ToString());
                }
            }
            this.SaveResoursesDepartament();
        }

        public override string ToString()
        {
            if (Workers.Count == 0)
            {
                return $"\nResourses dapartment(database) is empty\n";
            }
            string result = "\n";
            foreach (Worker worker in Workers)
            {
                result += worker.ToString();
                result += "\r\n";
            }
            return result;
        }
        private Worker GetWorkerParamsNoDateTime()
        {
            string WorkerName;
            int WorkerAge;
            string WorkerSex;
            int WorkerSalary;
            string WorkerEducation;
            string WorkerPosition;
            string WorkerDivision;

            Console.WriteLine("Enter Full name (String):                  Ex: Kostya Filei ");
            while (true)
            {
                string input = Console.ReadLine();
                if (input.Split(' ').Count() == 2)
                {
                    WorkerName = input;
                    break;
                }
                else Console.WriteLine("You entered invalid name");
            }
            string[] words = WorkerName.Split(' ');
            words[0] = char.ToUpper(words[0][0]) + words[0].Substring(1);
            words[1] = char.ToUpper(words[1][0]) + words[1].Substring(1);
            WorkerName = string.Join(" ", words);

            Console.WriteLine("Enter age (Int): ");
            while (true)
            {
                string input = Console.ReadLine();
                if (int.TryParse(input, out WorkerAge))
                {
                    if (WorkerAge >= 18 && WorkerAge < 150)
                    {
                        WorkerAge = Convert.ToInt32(input);
                        break;
                    }
                    else Console.WriteLine("Age cannot be < 18 and > 150");
                }
                else
                {
                    Console.WriteLine("You entered an invalid value. Please enter a valid integer value");
                }
            }

            Console.WriteLine("Enter sex (string) + (Enter only: Male or Female): ");
            while (true)
            {
                string input = Console.ReadLine();
                input = char.ToUpper(input[0]) + input.Substring(1);
                if (input == "Male" || input == "Female")
                {
                    WorkerSex = input;
                    break;
                }
                else Console.WriteLine("You enter invalid Sex value");
            }

            Console.WriteLine("Enter salary (Int): ");
            while (true)
            {
                string input = Console.ReadLine();
                if (int.TryParse(input, out WorkerSalary))
                {
                    if (Convert.ToInt32(input) > 0)
                    {
                        WorkerSalary = Convert.ToInt32(input);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("You entered an invalid value. Salary cannot be < 0");
                    }
                }
                else
                {
                    Console.WriteLine("You entered an invalid value. Please enter a valid integer value");
                }
            }

            Console.WriteLine("Enter education (String) + (Enter only: BA, PhD, MA): ");
            while (true)
            {
                string input = Console.ReadLine();
                if (input == "BA" || input == "PhD" || input == "MA")
                {
                    WorkerEducation = input;
                    break;
                }
                else Console.WriteLine("You entered an invalid value. Please enter BA, MA or PhD");
            }


            Console.WriteLine("Enter position (String): ");
            WorkerPosition = Console.ReadLine();
            WorkerPosition = char.ToUpper(WorkerPosition[0]) + WorkerPosition.Substring(1);

            Console.WriteLine("Enter division (String): ");
            WorkerDivision = Console.ReadLine();
            WorkerDivision = char.ToUpper(WorkerDivision[0]) + WorkerDivision.Substring(1);

            DateTime WorkerDateOfEntry = DateTime.Now;
            DateTime WorkerDateOfLastAppointment = DateTime.Now;
            Worker a = new Worker(WorkerName, WorkerAge, WorkerSex, WorkerSalary, WorkerEducation, WorkerPosition, WorkerDivision);
            return a;
        }
        private Worker ChangeWorkerDateTime(Worker worker)
        {
            bool check = false;
            foreach (var tempWorker in Workers)
            {
                if (tempWorker.Name == worker.Name && tempWorker.Age == worker.Age && tempWorker.Sex == worker.Sex && tempWorker.Salary == worker.Salary && tempWorker.Eduction == worker.Eduction && tempWorker.Position == worker.Position && tempWorker.Division == worker.Division && worker.Position != "Ceo")
                {
                    check = true;
                    worker.DateOfEntry = tempWorker.DateOfEntry;
                    worker.DateOfLastAppointment = tempWorker.DateOfLastAppointment;
                    break;
                }
            }
            if (check == true)
            {
                Console.WriteLine("Worker was succesfully fired");
                return worker;
            }
            else
            {
                Console.WriteLine("Worker was not fired.\tMaybe you entered wrong information or the worker is Ceo");
                return null;
            }
        }
        public void SaveResoursesDepartament()
        {
            string filePath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів 3спроба\SavedData\Database.txt";
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var workers in Workers)
                {
                    writer.WriteLine(workers.ToString());
                }
            }
        }
        public void LoadResoursedDepartamment()
        {
            Workers.Clear();
            string filePath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів 3спроба\SavedData\Database.txt";
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    var thisName = parts[0];
                    thisName = thisName.Substring(5);
                    int thisAge = int.Parse(parts[1].Substring(5));
                    var thisSex = parts[2].Substring(5);
                    int thisSalary = int.Parse(parts[3].Substring(8));
                    var thisEducation = parts[4].Substring(11);
                    var thisPosition = parts[5].Substring(10);
                    var thisDivision = parts[6].Substring(10);
                    var thisDateOfEntry = DateTime.Parse(parts[7].Substring(13));
                    var thisDateOfLastAppointment = DateTime.Parse(parts[8].Substring(23));
                    Worker newWorker = new Worker(thisName, thisAge, thisSex, thisSalary, thisEducation, thisPosition, thisDivision, thisDateOfEntry, thisDateOfLastAppointment);
                    this.AddWorker(newWorker);
                }
            }
            Console.WriteLine("Data loaded successfully.");
        }

        public List<Worker> SearchWorkerByParams()
        {
            List<Worker> SearchedWorkers = new List<Worker>();
            Console.WriteLine("Enter parameters you want to search with (Name, Age, Sex, Salary, Education, Position, Division, DateOfEntry, DateOfLastAppointment, Stop - to stop searching)");
            string command;
            while (true)
            {
                Console.Write("$parameters: ");
                command = Console.ReadLine().Trim();
                command = char.ToUpper(command[0]) + command.Substring(1);
                if (command == "Name")
                {
                    string WorkerName;
                    Console.WriteLine("Enter Full name (String):                  Ex: Kostya Filei ");
                    while (true)
                    {
                        string input = Console.ReadLine();
                        if (input.Split(' ').Count() == 2)
                        {
                            WorkerName = input;
                            break;
                        }
                        else Console.WriteLine("You entered invalid name");
                    }
                    string[] words = WorkerName.Split(' ');
                    words[0] = char.ToUpper(words[0][0]) + words[0].Substring(1);
                    words[1] = char.ToUpper(words[1][0]) + words[1].Substring(1);
                    WorkerName = string.Join(" ", words);
                    SearchedWorkers = Workers.Where(worker => worker.Name == WorkerName).ToList();
                }
                else if (command == "Age")
                {
                    int WorkerAge;
                    Console.WriteLine("Enter age (Int): ");
                    while (true)
                    {
                        string input = Console.ReadLine();
                        if (int.TryParse(input, out WorkerAge))
                        {
                            if (WorkerAge >= 18 && WorkerAge < 150)
                            {
                                WorkerAge = Convert.ToInt32(input);
                                break;
                            }
                            else Console.WriteLine("Age cannot be < 18 and > 150");
                        }
                        else
                        {
                            Console.WriteLine("You entered an invalid value. Please enter a valid integer value");
                        }
                    }
                    Console.WriteLine($"Do you want to search workers with less, more or equal to this({WorkerAge})?\nEnter: 1( >= {WorkerAge}), 2( <= {WorkerAge}), 3( = {WorkerAge})");
                    while (true)
                    {
                        string answer = Console.ReadLine().Trim();
                        if (answer == "1")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.Age >= WorkerAge).ToList();
                            break;
                        }
                        else if (answer == "2")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.Age <= WorkerAge).ToList();
                            break;
                        }
                        else if (answer == "3")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.Age == WorkerAge).ToList();
                            break;
                        }
                        else Console.WriteLine("You entered a wrong input. Try Again");
                    }
                }
                else if (command == "Sex")
                {
                    string WorkerSex;
                    Console.WriteLine("Enter sex (string) + (Enter only: Male or Female): ");
                    while (true)
                    {
                        string input = Console.ReadLine();
                        input = char.ToUpper(input[0]) + input.Substring(1);
                        if (input == "Male" || input == "Female")
                        {
                            WorkerSex = input;
                            break;
                        }
                        else Console.WriteLine("You enter invalid Sex value");
                    }
                    SearchedWorkers = Workers.Where(worker => worker.Sex == WorkerSex).ToList();
                }
                else if (command == "Salary")
                {
                    int WorkerSalary;
                    Console.WriteLine("Enter salary (Int): ");
                    while (true)
                    {
                        string input = Console.ReadLine();
                        if (int.TryParse(input, out WorkerSalary))
                        {
                            if (Convert.ToInt32(input) > 0)
                            {
                                WorkerSalary = Convert.ToInt32(input);
                                break;
                            }
                            else
                            {
                                Console.WriteLine("You entered an invalid value. Salary cannot be < 0");
                            }
                        }
                        else
                        {
                            Console.WriteLine("You entered an invalid value. Please enter a valid integer value");
                        }
                    }
                    Console.WriteLine($"Do you want to search workers with less, more or equal to this({WorkerSalary})?\nEnter: 1( >= {WorkerSalary}), 2( <= {WorkerSalary}), 3( = {WorkerSalary})");
                    while (true)
                    {
                        string answer = Console.ReadLine().Trim();
                        if (answer == "1")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.Salary >= WorkerSalary).ToList();
                            break;
                        }
                        else if (answer == "2")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.Salary <= WorkerSalary).ToList();
                            break;
                        }
                        else if (answer == "3")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.Salary == WorkerSalary).ToList();
                            break;
                        }
                        else Console.WriteLine("You entered a wrong input. Try Again");
                    }
                }
                else if (command == "Education")
                {
                    string WorkerEducation;
                    Console.WriteLine("Enter education (String) + (Enter only: BA, PhD, MA): ");
                    while (true)
                    {
                        string input = Console.ReadLine();
                        if (input == "BA" || input == "PhD" || input == "MA")
                        {
                            WorkerEducation = input;
                            break;
                        }
                        else Console.WriteLine("You entered an invalid value. Please enter BA, MA or PhD");
                    }
                    SearchedWorkers = Workers.Where(worker => worker.Eduction == WorkerEducation).ToList();
                }
                else if (command == "Position")
                {
                    Console.WriteLine("Enter position (String): ");
                    string WorkerPosition = Console.ReadLine();
                    WorkerPosition = char.ToUpper(WorkerPosition[0]) + WorkerPosition.Substring(1);
                    SearchedWorkers = Workers.Where(worker => worker.Position == WorkerPosition).ToList();
                }
                else if (command == "Division")
                {
                    Console.WriteLine("Enter division (String): ");
                    string WorkerDivision = Console.ReadLine();
                    WorkerDivision = char.ToUpper(WorkerDivision[0]) + WorkerDivision.Substring(1);
                    SearchedWorkers = Workers.Where(worker => worker.Division == WorkerDivision).ToList();
                }
                else if (command == "DateOfEntry")
                {
                    Console.WriteLine("Enter the Date of Entry (dd.MM.yyyy hh:mm:ss): ");
                    DateTime WorkerDateOfEntry;
                    while (true)
                    {
                        if (DateTime.TryParse(Console.ReadLine(), out DateTime newDate))
                        {
                            WorkerDateOfEntry = newDate;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Invalid date format! Please enter again");
                        }
                    }
                    Console.WriteLine($"Enter only: 1 - to search workers date of entry in time and after {WorkerDateOfEntry}\n" +
                        $"2 - to search workers date of entry in time and before {WorkerDateOfEntry}");
                    while (true)
                    {
                        string answer = Console.ReadLine().Trim();
                        if (answer == "1")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.DateOfEntry >= WorkerDateOfEntry).ToList();
                            break;
                        }
                        else if (answer == "2")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.DateOfEntry <= WorkerDateOfEntry).ToList();
                            break;
                        }
                        else Console.WriteLine("Try again ");
                    }
                }
                else if (command == "DateOfLastAppointment")
                {
                    Console.WriteLine("Enter the Date of Last Appointment (dd.MM.yyyy hh:mm:ss): ");
                    DateTime WorkerDateOfLastAppointment;
                    while (true)
                    {
                        if (DateTime.TryParse(Console.ReadLine(), out DateTime newDate))
                        {
                            WorkerDateOfLastAppointment = newDate;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Invalid date format! Please enter again");
                        }
                    }
                    Console.WriteLine($"Enter only: 1 - to search workers date of entry in time and after {WorkerDateOfLastAppointment}\n" +
                        $"2 - to search workers date of entry in time and before {WorkerDateOfLastAppointment}");
                    while (true)
                    {
                        string answer = Console.ReadLine().Trim();
                        if (answer == "1")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.DateOfEntry >= WorkerDateOfLastAppointment).ToList();
                            break;
                        }
                        else if (answer == "2")
                        {
                            SearchedWorkers = Workers.Where(worker => worker.DateOfEntry <= WorkerDateOfLastAppointment).ToList();
                            break;
                        }
                        else Console.WriteLine("Try again ");
                    }
                }
                else if (command == "Stop")
                {
                    break;
                }
                else Console.WriteLine("You entered non existing parameter");
            }
            return SearchedWorkers;
        }
        //public void ChangeWorkerParams()
        //{
        //    Console.WriteLine("Do you want to change name?\t (Enter: 1 - yes | 2 - no)");
        //    int answer = Convert.ToInt32(Console.ReadLine);
        //}
    }
    public class Program
    {
        static void Main(string[] args)
        {
            ResoursesDepartament database = new ResoursesDepartament();
            void UICommand()
            {
                Console.WriteLine("Enter commands such as: Hire, Fire, Print, Stop, Help, Save, Load, Clear, Search");
                string command;
                while (true)
                {
                    Console.Write("$Command: ");
                    command = Console.ReadLine().Trim();
                    if (command.Length == 0)
                    {
                        command = "NOTHING";
                    }
                    command = char.ToUpper(command[0])  + command.Substring(1);
                    if (command == "Hire")
                    {
                        database.CreateHireOrder();
                    }
                    else if (command == "Fire")
                    {
                        database.CreateFireOrder();
                    }
                    else if (command == "Print")
                    {
                        Console.WriteLine(database.ToString());
                    }
                    else if (command == "Stop" || command == "Close") break;
                    else if (command == "Save")
                    {
                        database.SaveResoursesDepartament();
                        Console.WriteLine("Changes saved to Database.txt file\n");
                    }
                    else if (command == "Help")
                    {
                        Console.WriteLine($"Hire - adds worker to a company(database) and creates an .txt HireOrder\n" +
                            $"Fire - deletes worker from a company(database) and creates an .txt FireOrder\n" +
                            $"Print - prints all of your resourses departament(database)\n" +
                            $"Stop - turns off the program\n" +
                            $"Save - saves all of your resourses departament changes to an existing Database.txt file\n" +
                            $"Load - loads all workers to your resourses departament from an existing Database.txt file\n" +
                            $"Search - searches for workers by a certain parameter (only 1 parameter) " +
                            $"Clear - to clear the console");
                    }
                    else if (command == "Load")
                    {
                        database.LoadResoursedDepartamment();
                    }
                    else if (command == "Search")
                    {
                        List<Worker> ResultAfterSearchingWorkers = database.SearchWorkerByParams();
                        foreach(Worker worker in ResultAfterSearchingWorkers)
                        {
                            Console.WriteLine(worker.ToString());
                        }
                    }
                    else if (command == "Clear")
                    {
                        Console.Clear();
                        Console.WriteLine("Enter commands such as: Hire, Fire, Print, Stop, Help, Save, Clear, Search");
                    }
                    else Console.WriteLine($"There is no command such as '{command}'");
                }
            }
            UICommand();
        }
    }
}