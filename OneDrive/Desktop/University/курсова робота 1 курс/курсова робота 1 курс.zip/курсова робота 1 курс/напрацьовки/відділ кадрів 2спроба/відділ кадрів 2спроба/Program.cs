﻿using System.Runtime.CompilerServices;
using System.IO;

namespace відділ_кадрів_2спроба
{
    internal class Program
    {
        class Database
        {
            public List<Spivrobitnik> Employees = new List<Spivrobitnik>();
           public Database(params Spivrobitnik[] spivrobitniki)
            { 
                foreach (var employee in spivrobitniki)
                {
                    Employees.Add(employee);
                }
            }
            public void Print()
            {
                foreach(var employee in Employees)
                {
                    Console.WriteLine(employee.ToString());
                }
            }
            public void Save()
            {
                string filePath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів 2спроба\database.txt";
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach(var employee in Employees)
                    {
                        writer.WriteLine(employee.ToString());
                    }
                }
            }
            public void Load()
            {
                string filePath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів 2спроба\database.txt";

                using (StreamReader reader = new StreamReader(filePath))
                {
                    Employees.Clear();
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        string[] data = line.Split(','); //данные разделены запятой
                        if (data.Length == 5)
                        {
                            string name = data[0].Split(':')[1].Trim();
                            int age = int.Parse(data[1].Split(':')[1].Trim());
                            string position = data[2].Split(':')[1].Trim();
                            int salary = int.Parse(data[3].Split(':')[1].Trim());
                            string sex = data[4].Split(":")[1].Trim();
                            Ceo ceo = new Ceo(name, age, position, salary, sex);
                            Employees.Add(ceo);
                        }
                        else if (data.Length == 6)
                        {
                            string name = data[0].Split(':')[1].Trim();
                            int age = int.Parse(data[1].Split(':')[1].Trim());
                            string position = data[2].Split(':')[1].Trim();
                            int salary = int.Parse(data[3].Split(':')[1].Trim());
                            string sex = data[4].Split(":")[1].Trim();
                            int portfolioAmount = int.Parse(data[5].Split(':')[1].Trim());
                            Programmer programmer = new Programmer(name, age, position, salary, sex, portfolioAmount);
                            Employees.Add(programmer);
                        }
                    }
                }
            }
            public void AddWorker()
            {
                Console.WriteLine("Enter worker Name: ");
                string name = Console.ReadLine();
                Console.WriteLine("Enter worker Age: ");
                int age = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter worker Salary: ");
                int salary = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter worker Sex: ");
                string sex = Console.ReadLine();
                string position;
                Console.WriteLine("Enter worker Position: ");
                while (true)
                {
                    position = Console.ReadLine();
                    if(position == "Ceo" || position == "Programmer")
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("You entered the wrong position");
                    }
                }
                if(position == "Programmer")
                {
                    Console.WriteLine("Enter worker portfolio Amount: ");
                    int portfolioAmount = Convert.ToInt32(Console.ReadLine());
                    Programmer programmer = new Programmer(name, age, position, salary, sex, portfolioAmount);
                    Employees.Add(programmer);
                }
                else
                {
                    Ceo ceo = new Ceo(name, age, position, salary, sex);
                    Employees.Add(ceo);
                }
            }
            public void AddWorker(Spivrobitnik employee)
            {
                Console.WriteLine("1212121");
                Employees.Add(employee);
            }
            public void RemoveEmployee(Spivrobitnik employee, Order order)
            {
                if (employee is Ceo)
                {
                    Console.WriteLine("You cannot fire the CEO");
                }
                else if (employee is Programmer)
                {
                    Employees.Remove(employee);
                    if(Employees.Remove(employee) == false)
                    {
                        foreach (var emp in Employees)
                        {
                            if (emp.Name == employee.Name &&
                                emp.Age == employee.Age &&
                                emp.Position == employee.Position &&
                                emp.Salary == employee.Salary &&
                                emp.Sex == employee.Sex)
                            {
                                Employees.Remove(emp);
                                Console.WriteLine($"Employee {employee.Name} removed from the database.");
                                return; 
                            }
                        }
                    }
                }
            }

        }
        abstract class Spivrobitnik
        {
            public Spivrobitnik(string name, int age, string position, int salary, string sex) {
                Name = name;
                Age = age;
                Position = position;
                Salary = salary;
                Sex = sex;
            }
            public string Name { get; set; }
            public int Age { get; set; }
            public string Position { get; set; }
            public int Salary { get; set; }
            public string Sex { get; set; }
            public override string ToString()
            {
                return $"Name:{Name}, Age:{Age}, Position:{Position}, Salary:{Salary}, Sex: {Sex}";
            }
        }
        class Ceo : Spivrobitnik
        {
            //ceo has no portfolio
            //ceo cannot be deleted
            //ceo can be added
            public Ceo(string name, int age, string position, int salary, string sex) : base(name, age, position, salary, sex)
            {
                
            }
        }
        class Programmer : Spivrobitnik
        {
            public Portfolio ProgrammerPortfolio { get; set; }
            public Programmer (string name, int age, string position, int salary, string sex,  int portfolioAmount) : base(name, age, position, salary, sex)
            {
                ProgrammerPortfolio = new Portfolio(portfolioAmount);
            }
            public override string ToString()
            {
                return $"{base.ToString()}, Portfolio Amount:{ProgrammerPortfolio.ProjectsAmount}";
            }
        }
        public class Portfolio
        {
            public int ProjectsAmount { get; set; }
            public Portfolio (int projectsAmount)
            {
                this.ProjectsAmount = projectsAmount;
            }
        }
        abstract class Order
        {
            public DateTime date { get; set; } = DateTime.Now;
        }
        class FireOrder : Order
        {
            bool CeoSignature { get; set; } = true;
            public FireOrder(Spivrobitnik worker, Database myDatabase)
            {
                if (worker.Age < 60) myDatabase.RemoveEmployee(worker, this);
                else Console.WriteLine("Worker is a pensioner, you cannot remove him as an ordinary Worker");
            }
            public override string ToString()
            {
                return $"CeoSignature: {CeoSignature}, date: {date}";
            }
        }
        class FirePensionerOrder : Order
        {
            public bool CeoSignature { get; set; } = true;
            public bool WorkerSignature { get; set; } = true;
            public FirePensionerOrder(Spivrobitnik worker, Database myDatabase)
            {
                if (worker.Age >= 60) myDatabase.RemoveEmployee(worker, this);
                else Console.WriteLine("Worker is not a pensioner");
            }
            public override string ToString()
            {
                return $"CeoSignature: {CeoSignature}, WorkerSignature: {WorkerSignature}, date: {date}";
            }
        }
        static void Main(string[] args)
        {
            Ceo a = new Ceo("Leonard", 30, "Ceo", 1234, "Male");
            Programmer b = new Programmer("Vasya", 20, "Programmer", 400, "Male",  10);
            Database myDatabse = new Database(a, b);
            myDatabse.Print();
            //myDatabse.Save();
            Console.WriteLine("------------------------------------------------------------------------");
            myDatabse.Load();
            myDatabse.Print();
            Console.WriteLine();
            //myDatabse.AddWorker();
            //myDatabse.RemoveEmployee(a);
            Ceo c = new Ceo("Bernard", 67, "Ceo", 1234, "Male");
            FireOrder order = new FireOrder(c, myDatabse);
            FirePensionerOrder order2 = new FirePensionerOrder(c, myDatabse);
            Programmer d = new Programmer("Bernard", 67, "Programmer", 1234, "Male", 13);
            myDatabse.AddWorker(d);
            myDatabse.Print();
            Console.WriteLine();
            FireOrder order3 = new FireOrder(d, myDatabse);
            FirePensionerOrder order4 = new FirePensionerOrder(d, myDatabse);
            Console.WriteLine();
            myDatabse.Print();
            Console.WriteLine();
            Console.ReadLine();
        }
    }
}