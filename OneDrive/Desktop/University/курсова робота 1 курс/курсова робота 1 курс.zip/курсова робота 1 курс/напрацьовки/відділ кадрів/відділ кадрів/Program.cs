﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
namespace відділ_кадрів
{
    /*
База даних про співробітників фірми: паспортні дані(Прізвище, Ім'я, вік),
освіта, спеціальність, підрозділ, посада, оклад, дати надходження у фірму і
останнього призначення та інше. Вибір за довільним шаблоном. Скорочення
штатів: вибір для звільнення осіб пенсійного та передпенсійного віку(за паспортними даними). 
    */
    public class database
    {
        public Dictionary<string, int> AmountDatabase {  get; set; }
        public database()
        {
            AmountDatabase = new Dictionary<string, int>();
        }
        public void Add(string key, int amount)
        {
            if (AmountDatabase.ContainsKey(key)) {
                AmountDatabase[key] += amount;
            }
            else { AmountDatabase.Add(key, amount);}
        }
        public void PrintAmount()
        {
            Console.WriteLine($"\n{GetType()}: ");
            foreach (var item in AmountDatabase)
            {
                Console.WriteLine($"Key: {item.Key}, Value: {item.Value}");
            }
        }
    }


    public class Workers
    {
        public Workers()
        {

        }
        public virtual void Add(database data, int amount)
        {
            data.Add("Workers", amount);
        }

        public void PrintAmount(database data)
        {
            Console.WriteLine($"\n{GetType()}: ");
            string keyToCompair = this.ToString();
            keyToCompair = keyToCompair.Substring(14);
            foreach (var item in data.AmountDatabase)
            {
                if(item.Key == $"{keyToCompair}")
                Console.WriteLine($"Key: {item.Key}, Value: {item.Value}");
            }
        }
    }
    class Managers : Workers
    {
        public Managers()
        {
            
        }
        public override void Add(database data, int amount)
        {
            base.Add(data, amount);
            data.Add("Managers", amount);
        }
    }
    class Programmers : Workers
    {
        public Programmers()
        {

        }
        public override void Add(database data, int amount)
        {
            base.Add(data, amount);
            data.Add("Programmers", amount);
        }
    }

    internal class Program
    {
    static void SaveDatabase(database data)
    {
        string fileName = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів\SavedData.txt";
        using (StreamWriter writer = new StreamWriter(fileName))
        {
            foreach (var item in data.AmountDatabase)
            {
                writer.WriteLine($"Key: {item.Key}, Value: {item.Value}");
            }
        }
    }
        static void LoadDatabase(database data)
        {
            string fileName = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\відділ кадрів\SavedData.txt";
            using (StreamReader reader = new StreamReader(fileName))
            {
                data.AmountDatabase.Clear();
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    int keyIndexStart = line.IndexOf(':');
                    int keyIndexEnd = line.IndexOf(',');
                    string key = line.Substring(keyIndexStart + 2, keyIndexEnd - 5);

                    int valueIndexStart = keyIndexStart + 2 + key.Length + 2 + 7;
                    int value = Convert.ToInt32(line.Substring(valueIndexStart));
                    data.AmountDatabase.Add(key, Convert.ToInt32(value));
                }
            }   
        }

        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            database data = new database();
            Workers a = new Workers();  
            a.Add(data, 12);
            a.PrintAmount(data);
            Managers b = new Managers();
            b.Add(data, 3);
            b.PrintAmount(data);
            a.PrintAmount(data);
            Programmers c = new Programmers();
            c.Add(data, 4);
            c.PrintAmount(data);
            a.PrintAmount(data);
            SaveDatabase(data);

            Console.WriteLine("----------------------------------------------------------------");
            LoadDatabase(data);
            data.PrintAmount();
        }
    }
}