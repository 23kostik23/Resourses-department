﻿using System;
using System.ComponentModel.Design;
using System.Globalization;
using System.IO;

namespace diary_with_database_c_sharp
{
    internal class Program
    {
        class Diary
        {
            static private List<dynamic> database = new List<dynamic>();
            public Diary(dynamic day, dynamic month, dynamic year)
            {
                database.Add(day);
                database.Add(month);
                database.Add(year);
            }
            public void Print()
            {
                if (database.Count == 0) Console.WriteLine("Your diary is empty");
                else
                {
                    int i = 0;
                    foreach(dynamic item in database)
                    {
                        if(i != 3) Console.Write(item + " ");
                        else
                        {
                            i = 0;
                            Console.Write("\n" + item + " ");
                        }
                        i++;
                    } 
                    Console.WriteLine();
                }
            }
            public void deleteDiary()
            {
                if (database.Count == 0) Console.WriteLine("Diary is already empty!");
                else
                {
                    for(int i = 0; i < 3 ; i++)
                    {
                        database.RemoveAt(database.Count - 1);
                    }
                }
            }
            public void saveDiary()
            {
                string filePath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\diary with database c sharp\database.txt";
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    int i = 0;
                    foreach (dynamic item in database)
                    {
                        if (i != 3) writer.Write(item + " ");
                        else
                        {
                            i = 0;
                            writer.Write("\n" + item + " ");
                        }
                        i++;
                    }
                }
                Console.WriteLine("Values had been written to the file");
            }
            public void loadDiary()
            {
                string filePath = @"C:\Users\kk648\OneDrive\Desktop\University\курсова робота 1 курс\напрацьовки\diary with database c sharp\database.txt";
                string temp = "";
                database.Clear();
                using (StreamReader reader = new StreamReader(filePath))
                {
                    temp = reader.ReadToEnd().ToString();
                    string[] arr = temp.Split(new char[] { ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string item in arr)
                    {
                        database.Add(item);
                    }
                }
                Console.WriteLine("Data have loaded");
            }
        }

        static void createDiary()
        {
            Console.WriteLine("Enter day, month and year in this order");
            string day = Console.ReadLine();
            dynamic month = Console.ReadLine();
            string year = Console.ReadLine();
            Diary b = new Diary(day, month, year);
        }

        static void Main(string[] args)
        {
            Diary a = new Diary(12, 2, 2006);
            string command = "";
            Console.WriteLine("Enter create, print, clear, delete, stop, save, load");
            while (true)
            {
                command = Console.ReadLine();
                if (command == "create") createDiary();
                else if (command == "print") a.Print();
                else if (command == "stop") break;
                else if (command == "clear")
                {
                    Console.Clear();
                    Console.WriteLine("Enter create, print, clear, delete, stop, save, load");
                }
                else if (command == "delete") a.deleteDiary();
                else if (command == "save") a.saveDiary();
                else if (command == "load") a.loadDiary();
                else Console.WriteLine($"there is no such a command {command}");
            }
        }
    }
}