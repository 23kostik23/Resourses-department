﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

class Diary {
private:
	int day;
	string month;
	int year;
	static vector <Diary> database;
public:
	Diary(int day, string month, int year) {
		this->day = day;
		this->month = month;
		this->year = year;
		database.push_back(*this);
	}
	static void PrintDatabase() {
		if (database.size() == 0) cout << "Diary is empty";
		else {
			cout << "Dairy database: " << endl;
			for (auto& entry : database) {
				cout << "Day: " << entry.day << ", month: " << entry.month << ", year: " << entry.year << endl;
			}
		}
	}
	static void deleteLastDiary() {
		if (!database.empty()) database.pop_back();
		else cout << "Error: Data base is empty" << endl;
	}
};

vector <Diary> Diary::database;

void createDiary() {
	int day, year;
	string month;
	cout << "enter day: ";
	cin >> day;
	cout << "enter month: ";
	cin >> month;
	cout << "enter year: ";
	cin >> year;
	Diary c(day, month, year);
}

int main() {
	Diary a(13, "may", 2002);
	Diary b(13, "may", 2006);
	string command = "0";
	while (command != "stop") {
		cout << endl << "Enter the command: ";
		cin >> command;
		if (command == "create") createDiary();
		else if (command == "print") Diary::PrintDatabase();
		else if (command == "help") cout << "You can enter commands: stop, create, print, clear, delete" << endl;
		else if (command == "clear") system("cls");
		else if (command == "delete") Diary::deleteLastDiary();
		else cout << "There is no such a command" << endl;
	}
	return 0;
}